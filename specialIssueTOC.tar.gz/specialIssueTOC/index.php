<?php
require_once('SpecialIssueTOC.inc.php');
return new SpecialIssueTOCPlugin();